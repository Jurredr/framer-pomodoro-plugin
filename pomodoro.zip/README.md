# Pomodoro Timer Framer plugin

A super simple Framer plugin to show a Pomodoro Timer while building.
